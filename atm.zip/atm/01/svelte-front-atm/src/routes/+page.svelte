
<script>
    import Atm from "./Atm.svelte";

</script>
<Atm/>